
import datetime
import time
import os
import config as cg
import json_creator as jc
import pandas as pd
import cleartax as ct
import json
import shutil

invoice_data = {}

def mainProcess():
    # print("test")
    try:
        xlsx_date = ''
        for filename in os.listdir(cg.input_directory):
            if filename.endswith('.xlsx') or filename.endswith('.xlx'):
                ct.info_logger.info(f'Converting file {filename} to clear json.')
                df = pd.read_excel(str(cg.input_directory) + str(filename))
                # print(df.head())
                # Add new columns with default or computed values
                df['DOC_STATUS'] = ''
                df['IRN'] = ''
                df['ACK_NO'] = ''
                df['ACK_DATE'] = ''
                df['SIGNED_INVOICE'] = ''
                df['QR_CODE'] = ''
                df['ERROR_MESSAGE'] = ''
                df['ANNEXURE_STATUS'] = ''
                df['EMAIL_STATUS'] = ''
                os.remove(str(cg.input_directory) + str(filename))
                # shutil.move((str(cg.input_directory) + str(filename)), cg.archive_raw_input)
                ct.info_logger.info(f"The file has been moved to '{str(cg.archive_raw_input)}'")
                new_file = str(cg.output) + str(filename).replace(".xlsx",".csv")
                ct.info_logger.info(f"New file has been crated in '{str(new_file)}'")
                df.to_csv(new_file, index=False)
            elif filename.endswith('.csv'):
                ct.info_logger.info(f'Converting file {filename} to clear json.')
                df = pd.read_csv(str(cg.input_directory) + str(filename))

                # Add new columns with default or computed values
                df['DOC_STATUS'] = ''
                df['IRN'] = ''
                df['ACK_NO'] = ''
                df['ACK_DATE'] = ''
                df['SIGNED_INVOICE'] = ''
                df['QR_CODE'] = ''
                df['ERROR_MESSAGE'] = ''
                df['ANNEXURE_STATUS'] = ''
                df['EMAIL_STATUS'] = ''
                df['PDF_STATUS'] = ''
                os.remove(str(cg.input_directory) + str(filename))
                # shutil.move((str(cg.input_directory) + str(filename)), cg.archive_raw_input)
                ct.info_logger.info(f"The file has been moved to '{str(cg.archive_raw_input)}'")
                new_file = str(cg.output) + str(filename).replace(".xlsx",".csv")
                ct.info_logger.info(f"New file has been crated in '{str(new_file)}'")
                df.to_csv(new_file, index=False)

        for filename in os.listdir(cg.output):
            if filename.endswith('.csv'): 
                ct.info_logger.info(f'Converting file {filename} to clear json.')
                df = pd.read_csv(str(cg.output) + str(filename))
                
                for i in range(0, len(df)):
                    
                    row = df.iloc[i]
                    t= row.to_dict()
                    invoice_number = t['No.']
                    print(invoice_number)
                    print(i)
                    invoice_data[f'{invoice_number}'], customer_no, buyer_gstin = jc.create_json(t)
                    print(invoice_data[f'{invoice_number}'])
                    payload = invoice_data[f'{invoice_number}']
                    irn, resp = ct.generate_IRN(payload)
                    # resp = json.load(resp)
                    reciever_email = t["Cust Email ID"]
                    print(resp)
                    inv_no = resp[0]["transaction"]["DocDtls"]["No"]
                    if irn != "":
                        df.loc[df['No.'] == str(inv_no), 'DOC_STATUS'] = resp[0]["document_status"]
                        df.loc[df['No.'] == str(inv_no), 'IRN'] = irn
                        df.loc[df['No.'] == str(inv_no), 'ACK_NO'] = resp[0]["govt_response"]["AckNo"]
                        df.loc[df['No.'] == str(inv_no), 'ACK_DATE'] = resp[0]["govt_response"]["AckDt"]
                        df.loc[df['No.'] == str(inv_no), 'SIGNED_INVOICE'] = resp[0]["govt_response"]["SignedInvoice"]
                        df.loc[df['No.'] == str(inv_no), 'QR_CODE'] = resp[0]["govt_response"]["SignedQRCode"]
                        df.loc[df['No.'] == str(inv_no), 'ERROR_MESSAGE'] = str(ct.error_message_list(resp))
                        response_pdf = ct.pdf(irn)
                        # Convert the string to a datetime object
                        date_obj = datetime.datetime.strptime(str(payload['transaction']['DocDtls']['Dt']), "%d/%m/%Y")

                        # Format the date to "Apr'23"
                        formatted_date = date_obj.strftime("%b'%y")

                        print(response_pdf.status_code)
                        # Check if the response is successful (status code 200)
                        if response_pdf.status_code == 200:
                            # Open a file in binary mode and write the content
                            
                            with open('data/pdf/'+str(customer_no) + "_" + str(buyer_gstin) + "_" + str(formatted_date) +'.pdf', 'wb') as pdf_file:
                                pdf_file.write(response_pdf.content)
                            ct.info_logger.info(f"PDF saved successfully with status code is {response_pdf.status_code}.")
                        else:
                            ct.error_logger(str(f"Failed to download PDF. Status code: {response_pdf.status_code}"))

                        annexure_status, email_status, pdf_status = jc.email(str(customer_no) + "_" + str(buyer_gstin) + "_" + str(formatted_date),str(payload['transaction']['DocDtls']['Dt']), reciever_email)
                        xlsx_date = formatted_date
                        if email_status == True:
                            df.loc[df['No.'] == str(inv_no), 'EMAIL_STATUS'] = "Success"
                        else:
                            df.loc[df['No.'] == str(inv_no), 'EMAIL_STATUS'] = "Failed"

                        if annexure_status == True:
                            df.loc[df['No.'] == str(inv_no), 'ANNEXURE_STATUS'] = "Success"
                        else:
                            df.loc[df['No.'] == str(inv_no), 'ANNEXURE_STATUS'] = "Failed"

                        if pdf_status == True:
                            df.loc[df['No.'] == str(inv_no), 'PDF_STATUS'] = "Success"
                        else:
                            df.loc[df['No.'] == str(inv_no), 'PDF_STATUS'] = "Failed"  

                        # if pdf_status == True:
                        #     df.loc[df['No.'] == str(inv_no), 'ERROR_MESSAGE'] = str(ct.error_message_list(resp))
                        
                    else:
                        df.loc[df['No.'] == str(inv_no), 'DOC_STATUS'] = resp[0]["document_status"]
                        df.loc[df['No.'] == str(inv_no), 'ERROR_MESSAGE'] = str(ct.error_message_list(resp))
                        df.loc[df['No.'] == str(inv_no), 'EMAIL_STATUS'] = "Failed"
                        df.loc[df['No.'] == str(inv_no), 'ANNEXURE_STATUS'] = "Failed"
                        df.loc[df['No.'] == str(inv_no), 'PDF_STATUS'] = "Failed" 
                # shutil.move((str(cg.input_directory) + str("output/") + str(filename)), cg.archive_raw_input)
                os.remove(str(cg.output) + str(filename))
                # shutil.move((str(cg.input_directory) + str(filename)), cg.archive_raw_input)
                ct.info_logger.info(f"The file has been removed from '{str(cg.output)}'")
                new_file = str(cg.final_output) + str(filename).replace(".xlsx","_").replace(".csv","_") + str(xlsx_date) + str(".csv")
                ct.info_logger.info(f"New file has been crated in '{str(new_file)}'")
                df.to_csv(new_file, index=False)
                print("Done")
            else:
                ct.error_logger.info(f'No excel file was found.')
    except Exception as e: 
        ct.error_logger.error(f"Exception:{str(e)}")
        os.remove(str(cg.output) + str(filename))
        # shutil.move((str(cg.input_directory) + str(filename)), cg.archive_raw_input)
        ct.info_logger.info(f"The file has been removed from '{str(cg.output)}'")
        new_file = str(cg.final_output) + str(filename).replace(".xlsx","_").replace(".csv","_") + str(xlsx_date) + str(".csv")
        ct.info_logger.info(f"New file has been crated in '{str(new_file)}'")
        df.to_csv(new_file, index=False)
        print("Done")
        

