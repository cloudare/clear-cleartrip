# # # test = 'Sahakar Bhavan Sub PostOffice,10th Floor,RCityMallLal BahadurShastriMargGhatkopar WestMumbaiSuburban'

# # # value = test.split(' ')

# # # for i in range(0, len(value)):
# # #     print(value[i])

# # # print(value[len(value) - 1])

# # import pandas as pd
# # import config as cg
# # import os
# # # Load the existing Excel file
# # existing_file = 'Hotel Commission -Sample format.xlsx'
# # sheet_name = 'Sheet1'  # Adjust the sheet name if necessary

# # # Read the Excel file into a DataFrame
# # df = pd.read_excel(existing_file, sheet_name=sheet_name)

# # # Add new columns with default or computed values
# # df['NewColumn1'] = ''          # Example of a column with default values
# # df['NewColumn2'] = "" # Example of a computed column (adjust accordingly)
# # os.remove(existing_file)
# # filename = 'Hotel Commission -Sample format.xlsx'
# # # Save the DataFrame to a new Excel file
# # new_file = str(existing_file)
# # df.to_excel(new_file, index=False)

# # df1 = pd.read_excel(new_file, sheet_name=sheet_name)
# # df1.loc[df['No.'] == 'SPINV202111467', 'NewColumn1'] = 'Test'
# # df1.to_excel(existing_file, index=False)

# # print(f"New file '{new_file}' created with additional columns.")


# import pandas as pd

# # Load the existing Excel file
# file_path = 'ClearTax Commission Hotel Annexure.xlsx'  # Replace with your file path

# # Read the Excel file into a DataFrame
# df = pd.read_excel(file_path)

# # Group the data by "Inv No"
# grouped = df.groupby('Inv No')

# # Create a new Excel file for each "Inv No"
# for inv_no, group in grouped:
#     # Define the output file name using the Inv No
#     output_file = f'Inv_No_{inv_no}.xlsx'
    
#     # Save each group into a new Excel file
#     group.to_excel(output_file, index=False)
#     print(f"Created file: {output_file}")


# Provided email string
email_string = "mohan.kumar@cleartrip.com,shwetasahadevs.vc@cleartrip.com,akshat.parashar1@cleartrip.com,sneha.hegde@cleartrip.com"

# Split the email IDs into a list
email_list = email_string.split(',')

# Create a new list to hold email IDs within the character limit
adjusted_email_list = []
current_length = 0
limit = 100

# Add email IDs while keeping the total length under the limit
for email in email_list:
    if current_length + len(email) + (len(adjusted_email_list) > 0) <= limit:
        adjusted_email_list.append(email)
        current_length += len(email) + 1  # Add 1 for the comma

# Join the adjusted list back into a string
adjusted_email_string = ','.join(adjusted_email_list)

print(f"Adjusted Email String: {adjusted_email_string}")
print(f"Character Length: {len(adjusted_email_string)}")
