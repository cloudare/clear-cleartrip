import requests
import json
import gzip
import os
import config as cg
import pandas as pd
# import logWriter as lw
# import cleartax as ct
# import sqlServer as db
import logging
from logging.handlers import RotatingFileHandler
import time
from datetime import datetime
import numpy as np
import config as cg


# response = json.dump([
#     {
#         "custom_fields": None,
#         "deleted": False,
#         "document_status": "IRN_GENERATED",
#         "error_response": None,
#         "errors": None,
#         "govt_response": {
#             "Success": "Y",
#             "AckNo": 112310153714784,
#             "AckDt": "2023-04-11 13:38:00",
#             "Irn": "94b6c41efd740424c469908d0927db66d8f24d9dad78b02dab04ad1659813dc9",
#             "SignedInvoice": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ0eXAiOiJKV1QiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNTM3MTQ3ODQsXCJBY2tEdFwiOlwiMjAyMy0wNC0xMSAxMzozODowMFwiLFwiSXJuXCI6XCI5NGI2YzQxZWZkNzQwNDI0YzQ2OTkwOGQwOTI3ZGI2NmQ4ZjI0ZDlkYWQ3OGIwMmRhYjA0YWQxNjU5ODEzZGM5XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJSZWdSZXZcIjpcIk5cIn0sXCJEb2NEdGxzXCI6e1wiVHlwXCI6XCJJTlZcIixcIk5vXCI6XCJJUk5URVNULzAwMlwiLFwiRHRcIjpcIjEwLzA0LzIwMjNcIn0sXCJTZWxsZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjI5QUFGQ0Q1ODYyUjAwMFwiLFwiTGdsTm1cIjpcIk5JQyBjb21wYW55IHB2dCBsdGRcIixcIlRyZE5tXCI6XCJOSUMgSW5kdXN0cmllc1wiLFwiQWRkcjFcIjpcIjV0aCBibG9jaywga3V2ZW1wdSBsYXlvdXRcIixcIkFkZHIyXCI6XCJrdXZlbXB1IGxheW91dFwiLFwiTG9jXCI6XCJCRU5HQUxVUlVcIixcIlBpblwiOjU2MDEwMyxcIlN0Y2RcIjpcIjI5XCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjI5QVdHUFY3MTA3QjFaMVwiLFwiTGdsTm1cIjpcIlhZWiBjb21wYW55IHB2dCBsdGRcIixcIlRyZE5tXCI6XCJYWVogSW5kdXN0cmllc1wiLFwiUG9zXCI6XCIyOVwiLFwiQWRkcjFcIjpcIjd0aCBibG9jaywga3V2ZW1wdSBsYXlvdXRcIixcIkFkZHIyXCI6XCJrdXZlbXB1IGxheW91dFwiLFwiTG9jXCI6XCJCRU5HQUxVUlVcIixcIlBpblwiOjU2MDEwNSxcIlN0Y2RcIjpcIjI5XCJ9LFwiRGlzcER0bHNcIjp7XCJObVwiOlwiQUJDIGNvbXBhbnkgcHZ0IGx0ZFwiLFwiQWRkcjFcIjpcIjd0aCBibG9jaywga3V2ZW1wdSBsYXlvdXRcIixcIkFkZHIyXCI6XCJrdXZlbXB1IGxheW91dFwiLFwiTG9jXCI6XCJCYW5hZ2Fsb3JlXCIsXCJQaW5cIjo1NjIxNjAsXCJTdGNkXCI6XCIyOVwifSxcIlNoaXBEdGxzXCI6e1wiR3N0aW5cIjpcIjI5QVdHUFY3MTA3QjFaMVwiLFwiTGdsTm1cIjpcIkNCRSBjb21wYW55IHB2dCBsdGRcIixcIlRyZE5tXCI6XCJrdXZlbXB1IGxheW91dFwiLFwiQWRkcjFcIjpcIjd0aCBibG9jaywga3V2ZW1wdSBsYXlvdXRcIixcIkFkZHIyXCI6XCJrdXZlbXB1IGxheW91dFwiLFwiTG9jXCI6XCJCYW5hZ2Fsb3JlXCIsXCJQaW5cIjo1NjIxNjAsXCJTdGNkXCI6XCIyOVwifSxcIkl0ZW1MaXN0XCI6W3tcIkl0ZW1Ob1wiOjAsXCJTbE5vXCI6XCIxXCIsXCJJc1NlcnZjXCI6XCJOXCIsXCJQcmREZXNjXCI6XCJTRVJWSUNFIENIQVJHRVMoU01BUlQgU1VJVEVTKSBcIixcIkhzbkNkXCI6XCIxMDAxOTkyMFwiLFwiUXR5XCI6MS4wLFwiRnJlZVF0eVwiOjEuMCxcIlVuaXRcIjpcIk9USFwiLFwiVW5pdFByaWNlXCI6MTAwLjAsXCJUb3RBbXRcIjoxMDAuMDAsXCJEaXNjb3VudFwiOjAuMDAsXCJBc3NBbXRcIjoxMDAuMDAsXCJHc3RSdFwiOjE4LjAwMCxcIklnc3RBbXRcIjowLjAwLFwiQ2dzdEFtdFwiOjkuMDAsXCJTZ3N0QW10XCI6OS4wMCxcIkNlc1J0XCI6MC4wMDAsXCJDZXNBbXRcIjowLjAwLFwiQ2VzTm9uQWR2bEFtdFwiOjAuMDAsXCJTdGF0ZUNlc1J0XCI6MC4wMDAsXCJTdGF0ZUNlc0FtdFwiOjAuMDAsXCJTdGF0ZUNlc05vbkFkdmxBbXRcIjowLjAwLFwiT3RoQ2hyZ1wiOjAuMDAsXCJUb3RJdGVtVmFsXCI6MTE4LjAwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MTAwLjAwLFwiQ2dzdFZhbFwiOjkuMDAsXCJTZ3N0VmFsXCI6OS4wMCxcIklnc3RWYWxcIjowLjAwLFwiQ2VzVmFsXCI6MC4wMCxcIlN0Q2VzVmFsXCI6MC4wMCxcIkRpc2NvdW50XCI6MC4wMCxcIk90aENocmdcIjowLjAwLFwiUm5kT2ZmQW10XCI6MC4wMCxcIlRvdEludlZhbFwiOjExOC4wMCxcIlRvdEludlZhbEZjXCI6MTE4LjAwfSxcIkV3YkR0bHNcIjp7XCJUcmFuc0lkXCI6XCIxMkFXR1BWNzEwN0IxWjFcIixcIlRyYW5zTmFtZVwiOlwiWFlaIEVYUE9SVFNcIixcIlRyYW5zTW9kZVwiOlwiMVwiLFwiRGlzdGFuY2VcIjoxMDAsXCJUcmFuc0RvY05vXCI6XCJEb2MwMVwiLFwiVHJhbnNEb2NEdFwiOlwiMTAvMDQvMjAyM1wiLFwiVmVoTm9cIjpcImthMTIzNDU2XCIsXCJWZWhUeXBlXCI6XCJSXCJ9fSIsImlzcyI6Ik5JQyBTYW5kYm94In0.gRfSVrHTCy-esoiCEnxGqRBFmVZxySyglU1vTQoef1Ip1HqV8ypeeZEfJuyCwkNADQ-Fh_q4aCrWVvF3WbH0Rqbab5bt-EZ_-TegdWgIPC_AgPWzmo8xq689si6BUf0w_u0O7NhTLROUOoj3soUEvEozAy5nYqCwVTIzYcBhCRCtGXW3241EfnCGTkzip6MhUw8sJXFApIeLO9jZPbaImYSsy1L7jeyOZAFtftjSefkpkEsO-xYL53bHe9yFu6w-QP0GAagxGyII373Q3P6LXdkaHAJwyXl_m-ydt4Vg0o1s65UK0PSGe02VfAkax64MdG7-SYgaFENEnZrzV9jACg",
#             "SignedQRCode": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ0eXAiOiJKV1QiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFGQ0Q1ODYyUjAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMjlBV0dQVjcxMDdCMVoxXCIsXCJEb2NOb1wiOlwiSVJOVEVTVC8wMDJcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTAvMDQvMjAyM1wiLFwiVG90SW52VmFsXCI6MTE4LjAwLFwiSXRlbUNudFwiOjEsXCJNYWluSHNuQ29kZVwiOlwiMTAwMTk5MjBcIixcIklyblwiOlwiOTRiNmM0MWVmZDc0MDQyNGM0Njk5MDhkMDkyN2RiNjZkOGYyNGQ5ZGFkNzhiMDJkYWIwNGFkMTY1OTgxM2RjOVwiLFwiSXJuRHRcIjpcIjIwMjMtMDQtMTEgMTM6Mzg6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.qry9RhVPOvD_ZpOdrbjXYTObUhMsEexWCdNqxTGwx7E1ewiEOSJIez7IX0znwyyP7zXExAkUQIfI5MLU7ClfjM7zCrt7cTIwoRygivGuiL3MCkbuAPzCEIqAMe5nLVaUhA4ASA0UbZhjFI2EyxklRRuIy7xSfWRQVNC_Hzu4S3bIiV-X9quM0QoD0xLd89f7rzM4-lIogIaxRjcx9aClpTg3nfWh20nmXqpTi2HAQ_LhEngXkaEj6RvvKM7LPdHYw4AMjtSjusqNWrvzH4w6-0liQKRETgmDGPeho9MLC6nOyBMoNXCuj5c3YYQcqq_AxtO-1DvPiwwO9XygZySLVw",
#             "Status": "ACT",
#             "EwbNo": 171010133427,
#             "EwbDt": "2023-04-11 13:38:00",
#             "EwbValidTill": "2023-04-12 23:59:00"
#         },
#         "group_id": None,
#         "gstin": "29AAFCD5862R000",
#         "is_deleted": False,
#         "owner_id": None,
#         "tag_identifier": None,
#         "transaction": {
#             "Version": "1.1",
#             "TranDtls": {
#                 "TaxSch": "GST",
#                 "RegRev": "N",
#                 "SupTyp": "B2B"
#             },
#             "DocDtls": {
#                 "Typ": "INV",
#                 "No": "IRNTEST/002",
#                 "Dt": "10/04/2023"
#             },
#             "SellerDtls": {
#                 "Gstin": "29AAFCD5862R000",
#                 "LglNm": "NIC company pvt ltd",
#                 "TrdNm": "NIC Industries",
#                 "Addr1": "5th block, kuvempu layout",
#                 "Addr2": "kuvempu layout",
#                 "Loc": "BENGALURU",
#                 "Pin": 560103,
#                 "Stcd": "29"
#             },
#             "BuyerDtls": {
#                 "Gstin": "29AWGPV7107B1Z1",
#                 "LglNm": "XYZ company pvt ltd",
#                 "TrdNm": "XYZ Industries",
#                 "Pos": "29",
#                 "Addr1": "7th block, kuvempu layout",
#                 "Addr2": "kuvempu layout",
#                 "Loc": "BENGALURU",
#                 "Pin": 560105,
#                 "Stcd": "29"
#             },
#             "DispDtls": {
#                 "Nm": "ABC company pvt ltd",
#                 "Addr1": "7th block, kuvempu layout",
#                 "Addr2": "kuvempu layout",
#                 "Loc": "Banagalore",
#                 "Pin": 562160,
#                 "Stcd": "29"
#             },
#             "ShipDtls": {
#                 "Gstin": "29AWGPV7107B1Z1",
#                 "LglNm": "CBE company pvt ltd",
#                 "TrdNm": "kuvempu layout",
#                 "Addr1": "7th block, kuvempu layout",
#                 "Addr2": "kuvempu layout",
#                 "Loc": "Banagalore",
#                 "Pin": 562160,
#                 "Stcd": "29"
#             },
#             "ItemList": [
#                 {
#                     "SlNo": "1",
#                     "PrdDesc": "SERVICE CHARGES(SMART SUITES) ",
#                     "IsServc": "N",
#                     "HsnCd": "10019920",
#                     "Qty": 1.000,
#                     "FreeQty": 1.000,
#                     "Unit": "OTH",
#                     "UnitPrice": 100.000,
#                     "TotAmt": 100.00,
#                     "Discount": 0.00,
#                     "AssAmt": 100.00,
#                     "GstRt": 18.00,
#                     "IgstAmt": 0.00,
#                     "CgstAmt": 9.00,
#                     "SgstAmt": 9.00,
#                     "CesRt": 0.00,
#                     "CesAmt": 0.00,
#                     "CesNonAdvlAmt": 0.00,
#                     "StateCesRt": 0.00,
#                     "StateCesAmt": 0.00,
#                     "StateCesNonAdvlAmt": 0.00,
#                     "OthChrg": 0.00,
#                     "TotItemVal": 118.00
#                 }
#             ],
#             "ValDtls": {
#                 "AssVal": 100.00,
#                 "CgstVal": 9.00,
#                 "SgstVal": 9.00,
#                 "IgstVal": 0.00,
#                 "CesVal": 0.00,
#                 "StCesVal": 0.00,
#                 "Discount": 0.00,
#                 "OthChrg": 0.00,
#                 "RndOffAmt": 0.00,
#                 "TotInvVal": 118.00,
#                 "TotInvValFc": 118.00
#             },
#             "EwbDtls": {
#                 "TransId": "12AWGPV7107B1Z1",
#                 "TransName": "XYZ EXPORTS",
#                 "TransMode": "1",
#                 "Distance": 100,
#                 "TransDocNo": "Doc01",
#                 "TransDocDt": "10/04/2023",
#                 "VehNo": "ka123456",
#                 "VehType": "R"
#             }
#         },
#         "transaction_id": "29AAFCD5862R000_IRNTEST/002_INV_2023",
#         "transaction_metadata": None
#     }
# ])
# invoice_data = {}

# Function to create a logger with multiple file handlers
def setup_logger(name, log_file, level=logging.INFO):
    """Create a logger with the given name, log file, and log level."""
    
    log_dir = os.path.dirname('data/log_file')
    if not os.path.exists(log_dir) and log_dir != '':
        os.makedirs(log_dir)

    logger = logging.getLogger(name)
    if not logger.hasHandlers():
        logger.setLevel(level)

        # Create file handler for logging
        handler = RotatingFileHandler(log_file, maxBytes=2000000, backupCount=3)
        handler.setLevel(level)

        # Create a logging format that includes function name and line number
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(funcName)s - Line: %(lineno)d - %(message)s')
        handler.setFormatter(formatter)

        # Add the handler to the logger
        logger.addHandler(handler)

    return logger

current_date = datetime.now().strftime("%Y-%m-%d")
info_filename = f'data/log_file/info_{current_date}.log'
error_filename = f'data/log_file/error_{current_date}.log'
# Create different loggers for different log files
info_logger = setup_logger('info_logger', info_filename, level=logging.INFO)
error_logger = setup_logger('error_logger', error_filename, level=logging.ERROR)

def header(gstin):
    headers = {
        "X-Cleartax-Auth-Token": cg.headToken,#"1.6fa08b96-6335-4b61-8159-7dee044061bd_4ca6350826c4053153ad317f0b3ab17b71f4d7ffa9088d4be595f206b43191a2",
        "gstin": str(gstin),
        "Content-Type": "application/json"
        # "Accept": "*/*"
    }
    return headers

def header_buyer():
    headers = {
        "x-cleartax-auth-token": cg.headToken_gst,#"1.6fa08b96-6335-4b61-8159-7dee044061bd_4ca6350826c4053153ad317f0b3ab17b71f4d7ffa9088d4be595f206b43191a2",
        "Content-Type": "application/json",
        "x-ct-api-key": cg.api_key,
        "x-ct-sourcetype": 'API',
        "Accept": "*/*"
    }
    return headers

def generate_IRN(json_file):
    try:
        invoice=[]
        invoice.append(json_file) 
        print(cg.api_url)
        print()
        response = requests.put(cg.api_url, headers=header(json_file['transaction']['SellerDtls']['Gstin']), json=invoice)

        response_data = response.json() #json.loads(response.text)

        print(response_data)
        info_logger.info(response_data)
        time.sleep(5)
    except Exception as e: 
            error_logger.error(f"Error while generating the IRN:{str(e)}")
    try:
        if response_data[0]["govt_response"]["ErrorDetails"][0]["error_code"] is not None:
            error_logger.error(f"Error genarting IRN: {str(error_message_list(response_data))}")
            return "", response_data
    except Exception as e:
        print(str(e))
        try:
            # print(response_data[0]["document_status"])
            if response_data[0]["document_status"] == "IRN_GENERATED":
                try:
                    irn = response_data[0]["govt_response"]["Irn"]
                    return irn, response_data
                    # pdf(irn, invoice_number, seller_gst, buyer_gst)
                except:

                    error_logger.error(f"Error genarting IRN: {str(error_message_list(response_data))}")
                    return "", response_data
            else:
                error_logger.error(f"Error genarting IRN: {str(error_message_list(response_data))}")
                return "", response_data
                # break
        except:

            error_logger.error(f"Error genarting IRN: {str(error_message_list(response_data))}")
            return "", response_data
        
def error_message_list(data):
    error_messages = []
    # Extract error messages from the provided data
    for entry in data:
        try:
            govt_response = entry["govt_response"]
            error_details = govt_response["ErrorDetails"]

            for error_detail in error_details:
                error_message = error_detail["error_message"]
                if error_message:
                    error_messages.append(error_message)
        except:
            try:
                error_messages = data["error_message"]
            except (KeyError, TypeError) as e:
                print("Error extracting messages:", e)

    return error_messages

def get_buyer(gstin):
    try:
        header = header_buyer()
        info_logger.info(f"The header for Buyer GSTIN API is {header}.")
        api_url = str(cg.get_buyer) + str(gstin)
        info_logger.info(f"The url for Buyer GSTIN API is {api_url}.")
        response = requests.get(api_url, headers=header)

        response_data = response.json() #json.loads(response.text)
        info_logger.info(f"The response for the Buyer GSTIN API is {response_data}.")
        return response_data
        # time.sleep(5)
    except Exception as e: 
        error_logger.error(f"Error while calling the Buyer GSTIN API:{str(e)}")


def pdf(irn):
    try:
        headers = header("27AAFCD5862R013") # 
        info_logger.info(f"The header for PDF is: {headers}")
        api_url = '{}format=PDF&irns={}'.format(cg.api_pdf, irn)
        info_logger.info(f"The API url for PDF is: {api_url}")
        response_pdf = requests.get(
                api_url,
                headers=headers)
        info_logger.info(f"The json file for PDF is :{response_pdf}")
        return response_pdf
    except Exception as e: 
        error_logger.error(f"Error for PDF API is:{str(e)}")